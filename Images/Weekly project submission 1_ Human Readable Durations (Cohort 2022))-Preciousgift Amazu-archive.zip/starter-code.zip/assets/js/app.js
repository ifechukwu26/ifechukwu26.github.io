const person = window.prompt("Please enter your name");
const time = window.prompt("Please enter your time in minutes");

document.write("Hello " + person + ", your time in minutes is " + time + "minutes<br>");

const hours = Math.floor(time / 60);
const minutes = time % 60;

document.write("Output: " + hours + " hours and " + minutes + "minutes");